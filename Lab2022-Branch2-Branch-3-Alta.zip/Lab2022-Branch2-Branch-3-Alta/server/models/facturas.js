class Facturas{
    constructor(Recno,
        Is_Deleted,
        Fvid,
        Fvume,
        Fves,
        Fvts,
        Fvef,
        Fvrf,
        Fvqp,
        Fvqmc,
        Fvqmv,
        Fvqmex,
        Fvqmgr,
        Fvqmii,
        Fvqmig,
        Fvqmigs,
        Fvqmis,
        Fvqmiss,
        Fvqmoi,
        Fvqm,
        Fvsqm,
        Fvsqp,
        Fvmp,
        Fvmps,
        Fviv,
        Fvmme,
        Fvmm,
        Fvlt,
        Fvty,
        Ie$0,
        Fvaf,
        Fvafid,
        Fvcae,
        Fvcaefv,
        Fvca){
this.Recno = Recno;
this.Is_Deleted = Is_Deleted;
this.Fvid = Fvid;
this.Fvume = Fvume;
this.Fves = Fves;
this.Fvts = Fvts;
this.Fvef = Fvef;
this.Fvrf = Fvrf;
this.Fvqp = Fvqp;
this.Fvqmc = Fvqmc;
this.Fvqmv = Fvqmv;
this.Fvqmex = Fvqmex;
this.Fvqmgr = Fvqmgr;
this.Fvqmii = Fvqmii;
this.Fvqmig = Fvqmig;
this.Fvqmigs = Fvqmigs;
this.Fvqmis = Fvqmis;
this.Fvqmiss = Fvqmiss;
this.Fvqmoi = Fvqmoi;
this.Fvqm = Fvqm;
this.Fvsqm = Fvsqm;
this.Fvsqp = Fvsqp;
this.Fvmp = Fvmp;
this.Fvmps = Fvmps;
this.Fviv = Fviv;
this.Fvmme = Fvmme;
this.Fvmm = Fvmm;
this.Fvlt = Fvlt;
this.Fvty = Fvty;
this.$Ie0 = $Ie0;
this.Fvaf = Fvaf;
this.Fvafid = Fvafid;
this.Fvcae = Fvcae;
this.Fvcaefv = Fvcaefv;
this.Fvca = Fvca;
    }  
}

module.exports = Facturas;